# Build a 2D Platformer Game in Unity | Unity Beginner Tutorial

Watch the course here: https://www.youtube.com/playlist?list=PLrnPJCHvNZuCVTz6lvhR81nnaf1a-b67U

![thumbnail part 1](https://user-images.githubusercontent.com/52977034/119971715-9d0e2a80-bfb1-11eb-8938-b9da00b22b1f.png)
